from clrprint import *
clrprint('Rosewell', 'B', 'A', 'S', 'I', 'C', clr=['white', 'red', 'yellow', 'green', 'blue', 'purple'])
