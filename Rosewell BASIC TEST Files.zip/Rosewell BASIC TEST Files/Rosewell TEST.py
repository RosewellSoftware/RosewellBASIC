enter = input('Please Enter a Answer[Yes/No]:' )
if enter in ['Yes', 'yes', 'Y', 'y']:
    print("Hello World " * 5000)
elif enter in ['No', 'no', 'N', 'n']:
    print('Rosewell BASIC! ' * 5000)
print("Back to Basic!")
