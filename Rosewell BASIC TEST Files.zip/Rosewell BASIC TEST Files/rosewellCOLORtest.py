from clrprint import *
clrprint('c', 'o','l','o','r', clr=['red','yellow','green','blue','purple'])
print('''
This is What Colour Could look like in Rosewell BASIC Terminal!
This is using the Clrprint Module = from clrprint import *''')
