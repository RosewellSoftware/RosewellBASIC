from clrprint import *
clrprint('c', 'o','l','o','r', clr=['red','yellow','green','blue','purple'])
