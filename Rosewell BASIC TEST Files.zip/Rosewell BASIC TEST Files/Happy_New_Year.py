import time
import os
import pyttsx3
import threading
from playsound import playsound

engine = pyttsx3.init()

def present_year():
    return get_time('%Y')

def timeprint():
    while True:
        current = get_time()
        print(current)
        time.sleep(1)

def get_time(time_format = '%Y-%m-%d %H:%M:%S'):
    return time.strftime(time_format, time.localtime(time.time()))

def play_cheer():
    playsound("cheer.mp3")

def play_timeleft(timeleft):
    if timeleft == 10:
        engine.say('10 minutes left')
    elif timeleft == 5:
        engine.say('5 minutes left')
    elif timeleft == 1:
        engine.say('A minute left')
    elif timeleft == 30:
        engine.say('30 seconds left')
    engine.runAndWait()

def play_thing(word):
    engine.say(word)
    engine.runAndWait()

thread = threading.Thread(target=timeprint)
thread.start()

while True:
    current_date = int(get_time('%m%d'))
    current_hm = int(get_time('%H%M%S'))
    if current_date == 1231 and current_hm == 235950:
        for i in range(10, -1 , -1):
            if i == 0:
                play_thing("Happy New Year")
                print(f"Happy New Year of {present_year()}!!!")
            else:
                play_thing(str(i))
        play_cheer()
        break
    elif current_date == 1231 and current_hm == 235000:
        play_timeleft(10)
    elif current_date == 1231 and current_hm == 235500:
        play_timeleft(5)
    elif current_date == 1231 and current_hm == 235900:
        play_timeleft(1)
    elif current_date == 1231 and current_hm == 235930:
        play_timeleft(30)

thread.join()
