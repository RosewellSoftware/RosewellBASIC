from clrprint import *
clrprint('c', 'o','l','o','r', clr=['red','yellow','green','blue','purple'])
print(" ")
enter = input()
enterx = input('r/y/g/b/p?' )
if enterx == 'r' or enterx == 'RED' or enterx == 'Red' or enterx == 'red' or enterx == 'R':
  clrprint(enter, clr='red')
elif enterx in ['yellow','Yellow','y','Y','YELLOW']:
  clrprint(enter, clr='yellow')
elif enterx in ['green','Green','G','g','GREEN']:
  clrprint(enter, clr='green')
elif enterx in ['b','B','Blue','blue','BLUE']:
  clrprint(enter, clr='blue')
elif enterx in ['purple','Purple','P','p','PURPLE']:
  clrprint(enter, clr='purple')
